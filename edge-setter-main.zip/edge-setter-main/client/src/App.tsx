import { Switch, Route, Router, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { useState, useEffect } from "react";

import LandingPage from "./pages/LandingPage";
import Dashboard from "./pages/Dashboard";
import AdminReview from "./pages/AdminReview";
import SourceLeaderboard from "./pages/SourceLeaderboard";
import DraftBoard from "./pages/DraftBoard";
import AlertsPage from "./pages/AlertsPage";
import AgentLogs from "./pages/AgentLogs";
import SignalsPage from "./pages/SignalsPage";
import ProPage from "./pages/ProPage";
import LoginPage from "./pages/LoginPage";
import SuccessPage from "./pages/SuccessPage";
import SignalAdmin from "./pages/SignalAdmin";
import SignalOpsQueue from "./pages/SignalOpsQueue";
import SiteWatchLogs from "./pages/SiteWatchLogs";
import DistributionDrafts from "./pages/DistributionDrafts";
import DailyOps from "./pages/DailyOps";
import LiveIntelligenceHome from "./pages/LiveIntelligenceHome";
import FlagshipHome from "./pages/FlagshipHome";
import NBABoard from "./pages/NBABoard";
import MLBBoard from "./pages/MLBBoard";
import NFLBoard from "./pages/NFLBoard";
import CFBBoard from "./pages/CFBBoard";
import ToolsHub from "./pages/ToolsHub";
import MyEdge from "./pages/MyEdge";
import AlertSettingsPage from "./pages/AlertSettingsPage";
import AccuracyPage from "./pages/AccuracyPage";
import Billing from "./pages/Billing";
import PlayerSignals from "./pages/PlayerSignals";
import MarketMovement from "./pages/MarketMovement";
import OpsBoard from "./pages/OpsBoard";
import NotFound from "./pages/not-found";
import { SignalGateProvider } from "./context/SignalGate";
import { AuthProvider } from "./context/AuthContext";
import { AdminGate } from "./components/AdminGate";
import { ProModal } from "./components/ProGate";

export type Theme = "dark" | "light";

function HomeRedirect() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    setLocation("/");
  }, [setLocation]);

  return null;
}

function App() {
  const [theme, setTheme] = useState<Theme>("dark");

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [theme]);

  const toggleTheme = () => setTheme(t => t === "dark" ? "light" : "dark");

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
      <SignalGateProvider>
      <ProModal />
      <Router>
        <Switch>
          {/* ── Main routes ── */}
          <Route path="/" component={LiveIntelligenceHome} />
          <Route path="/nba" component={NBABoard} />
          <Route path="/mlb" component={MLBBoard} />
          <Route path="/nfl" component={NFLBoard} />
          <Route path="/cfb" component={CFBBoard} />
          <Route path="/tools" component={ToolsHub} />
          <Route path="/tools/player-signals" component={PlayerSignals} />
          <Route path="/tools/market-movement" component={MarketMovement} />
          <Route path="/my-edge" component={MyEdge} />
          <Route path="/sources" component={SourceLeaderboard} />
          <Route path="/accuracy" component={AccuracyPage} />
          <Route path="/billing" component={Billing} />
          <Route path="/alerts" component={AlertSettingsPage} />
          <Route path="/login" component={LoginPage} />
          <Route path="/pro" component={ProPage} />
          <Route path="/success" component={SuccessPage} />

          {/* ── Legacy v2 compatibility — keep deep links, send bare /v2 home ── */}
          <Route path="/v2" component={HomeRedirect} />
          <Route path="/v2/nba" component={NBABoard} />
          <Route path="/v2/mlb" component={MLBBoard} />
          <Route path="/v2/nfl" component={NFLBoard} />
          <Route path="/v2/cfb" component={CFBBoard} />
          <Route path="/v2/tools" component={ToolsHub} />
          <Route path="/v2/my-edge" component={MyEdge} />
          <Route path="/v2/sources" component={SourceLeaderboard} />
          <Route path="/leaderboard" component={SourceLeaderboard} />

          {/* ── Admin routes ── */}
          <Route path="/dashboard" component={() => <Dashboard theme={theme} toggleTheme={toggleTheme} />} />
          <Route path="/admin" component={() => <AdminGate><AdminReview theme={theme} toggleTheme={toggleTheme} /></AdminGate>} />
          <Route path="/admin/ops" component={() => <AdminGate><OpsBoard /></AdminGate>} />
          <Route path="/signal-admin" component={SignalAdmin} />
          <Route path="/signal-ops-queue" component={() => <AdminGate><SignalOpsQueue theme={theme} toggleTheme={toggleTheme} /></AdminGate>} />
          <Route path="/site-watch-logs" component={() => <AdminGate><SiteWatchLogs theme={theme} toggleTheme={toggleTheme} /></AdminGate>} />
          <Route path="/distribution-drafts" component={() => <AdminGate><DistributionDrafts theme={theme} toggleTheme={toggleTheme} /></AdminGate>} />
          <Route path="/daily-ops" component={() => <AdminGate><DailyOps theme={theme} toggleTheme={toggleTheme} /></AdminGate>} />
          <Route path="/signals" component={SignalsPage} />
          <Route path="/logs" component={() => <AdminGate><AgentLogs theme={theme} toggleTheme={toggleTheme} /></AdminGate>} />
          <Route path="/draft" component={() => <DraftBoard theme={theme} toggleTheme={toggleTheme} />} />

          <Route component={NotFound} />
        </Switch>
      </Router>
      </SignalGateProvider>
      </AuthProvider>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
