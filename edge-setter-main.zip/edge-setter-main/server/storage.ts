import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import path from "path";
import fs from "fs";
import { eq, desc, and, or } from "drizzle-orm";
import {
  sources, events, claims, evidence, verdicts,
  source_scores, alerts, waitlist, agent_logs,
  signals, source_notes, users, event_log, digest_subscribers,
  type Source, type InsertSource,
  type Event, type InsertEvent,
  type Claim, type InsertClaim,
  type Evidence, type InsertEvidence,
  type Verdict, type InsertVerdict,
  type SourceScore, type InsertSourceScore,
  type Alert, type InsertAlert,
  type Waitlist, type InsertWaitlist,
  type AgentLog, type InsertAgentLog,
  type SignalFeedItem,
  type Signal, type InsertSignal,
  type SourceNote, type InsertSourceNote,
  type User, type InsertUser,
  type EventLog, type InsertEventLog,
  type DigestSubscriber, type InsertDigestSubscriber,
} from "@shared/schema";
import type { OddsSnapshotRow, SignalLifecycleState } from "./pipeline/store";
import type { LiveSignal } from "./pipeline/types";

// Resolve a writable directory for SQLite.
// Priority: DATA_DIR env var → /tmp (always writable) → . (local dev)
function resolveDataDir(): string {
  const candidates = [
    process.env.DATA_DIR,
    "/tmp",
    ".",
  ].filter(Boolean) as string[];

  for (const dir of candidates) {
    try {
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      // Probe write access
      const probe = path.join(dir, ".write_probe");
      fs.writeFileSync(probe, "1");
      fs.unlinkSync(probe);
      return dir;
    } catch {
      // Not writable — try next candidate
    }
  }
  return ".";
}

const dataDir = resolveDataDir();
console.log(`[db] SQLite data directory: ${dataDir}`);
const dbPath = path.join(dataDir, "edge_setter.db");
const sqlite = new Database(dbPath);
sqlite.pragma("journal_mode = WAL");
const db = drizzle(sqlite);

// ─── Schema init ─────────────────────────────────────────────────────────────
sqlite.exec(`
  CREATE TABLE IF NOT EXISTS sources (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    source_type TEXT NOT NULL,
    team TEXT,
    platform TEXT,
    url TEXT,
    trust_tier TEXT,
    reliability_score NUMERIC DEFAULT 50,
    speed_score NUMERIC DEFAULT 50,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS events (
    id TEXT PRIMARY KEY,
    sport TEXT NOT NULL DEFAULT 'football',
    league TEXT,
    team TEXT,
    player TEXT,
    topic TEXT,
    cluster_key TEXT,
    urgency_score NUMERIC DEFAULT 0,
    impact_score NUMERIC DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS claims (
    id TEXT PRIMARY KEY,
    event_id TEXT REFERENCES events(id),
    source_id TEXT REFERENCES sources(id),
    claim_type TEXT,
    raw_claim_text TEXT,
    normalized_claim TEXT,
    claim_status TEXT DEFAULT 'pending',
    confidence_score NUMERIC DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS evidence (
    id TEXT PRIMARY KEY,
    claim_id TEXT REFERENCES claims(id),
    source_url TEXT,
    evidence_type TEXT,
    stance TEXT,
    extracted_text TEXT,
    authority_level INTEGER DEFAULT 1,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS verdicts (
    id TEXT PRIMARY KEY,
    claim_id TEXT REFERENCES claims(id),
    verdict TEXT,
    confidence_score NUMERIC,
    rationale TEXT,
    needs_human_review INTEGER DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS source_scores (
    id TEXT PRIMARY KEY,
    source_id TEXT REFERENCES sources(id),
    overall_accuracy NUMERIC DEFAULT 0,
    average_lead_time_minutes NUMERIC DEFAULT 0,
    draft_accuracy NUMERIC DEFAULT 0,
    injury_accuracy NUMERIC DEFAULT 0,
    portal_accuracy NUMERIC DEFAULT 0,
    false_positive_rate NUMERIC DEFAULT 0,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS alerts (
    id TEXT PRIMARY KEY,
    verdict_id TEXT REFERENCES verdicts(id),
    channel TEXT,
    audience TEXT,
    message_text TEXT,
    sent_at TEXT,
    click_count INTEGER DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS waitlist (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL,
    name TEXT,
    role TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS signals (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    slug TEXT NOT NULL,
    player_name TEXT NOT NULL,
    team TEXT NOT NULL,
    signal_type TEXT NOT NULL,
    status_tag TEXT NOT NULL DEFAULT 'verified',
    confidence_score INTEGER NOT NULL DEFAULT 80,
    source_count INTEGER NOT NULL DEFAULT 1,
    topic TEXT,
    verdict TEXT NOT NULL,
    summary TEXT NOT NULL,
    action_takeaway TEXT NOT NULL,
    published_at TEXT DEFAULT CURRENT_TIMESTAMP,
    is_featured INTEGER DEFAULT 0,
    is_public INTEGER DEFAULT 1,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS source_notes (
    id TEXT PRIMARY KEY,
    signal_id TEXT REFERENCES signals(id),
    source_name TEXT NOT NULL,
    source_type TEXT NOT NULL,
    trust_score INTEGER,
    note TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    first_name TEXT,
    plan TEXT NOT NULL DEFAULT 'free',
    stripe_customer_id TEXT,
    stripe_subscription_id TEXT,
    access_status TEXT NOT NULL DEFAULT 'pending',
    billing_status TEXT DEFAULT 'active',
    billing_email_sent TEXT,
    beta_until TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS event_log (
    id TEXT PRIMARY KEY,
    event_name TEXT NOT NULL,
    email TEXT,
    user_id TEXT,
    metadata TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS agent_logs (
    id TEXT PRIMARY KEY,
    timestamp TEXT NOT NULL,
    agent_name TEXT NOT NULL,
    input_ref TEXT,
    output_ref TEXT,
    decision_summary TEXT,
    error_state TEXT,
    warning_state TEXT
  );
  CREATE TABLE IF NOT EXISTS signal_ops_queue (
    id TEXT PRIMARY KEY,
    source_name TEXT NOT NULL,
    source_url TEXT,
    raw_headline TEXT NOT NULL,
    raw_body TEXT,
    player_tags TEXT DEFAULT '[]',
    team_tags TEXT DEFAULT '[]',
    ingest_timestamp TEXT NOT NULL,
    cluster_id TEXT,
    normalized_headline TEXT,
    normalized_summary TEXT,
    player TEXT,
    team TEXT,
    signal_type TEXT,
    confidence_score INTEGER DEFAULT 0,
    decision TEXT NOT NULL DEFAULT 'pending',
    reason TEXT,
    source_count INTEGER DEFAULT 1,
    conflict_flags TEXT DEFAULT '[]',
    signal_id TEXT REFERENCES signals(id),
    processed_at TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS site_watch_log (
    id TEXT PRIMARY KEY,
    run_timestamp TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'ok',
    checks TEXT NOT NULL DEFAULT '[]',
    anomalies TEXT NOT NULL DEFAULT '[]',
    recommended_action TEXT,
    alert_sent INTEGER DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS digest_subscribers (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    unsubscribe_token TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    source TEXT NOT NULL DEFAULT 'landing',
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS distribution_drafts (
    id TEXT PRIMARY KEY,
    signal_id TEXT NOT NULL REFERENCES signals(id),
    channel TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    copy TEXT NOT NULL,
    headline TEXT NOT NULL,
    notes TEXT DEFAULT '',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS daily_ops_summary (
    id TEXT PRIMARY KEY,
    date TEXT NOT NULL,
    generated_at TEXT NOT NULL,
    site_health TEXT NOT NULL DEFAULT '{}',
    signal_pipeline TEXT NOT NULL DEFAULT '{}',
    content_queue TEXT NOT NULL DEFAULT '{}',
    funnel TEXT NOT NULL DEFAULT '{}',
    top_actions TEXT NOT NULL DEFAULT '[]',
    email_sent INTEGER NOT NULL DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS pipeline_health (
    component   TEXT PRIMARY KEY,
    last_run_at TEXT,
    last_status TEXT,
    last_result TEXT
  );
  CREATE TABLE IF NOT EXISTS alert_preferences (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    leagues TEXT NOT NULL DEFAULT '["NBA","MLB"]',
    signal_types TEXT NOT NULL DEFAULT '[]',
    min_confidence INTEGER NOT NULL DEFAULT 80,
    channels TEXT NOT NULL DEFAULT '["email"]',
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS push_subscriptions (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL,
    endpoint TEXT NOT NULL UNIQUE,
    p256dh TEXT NOT NULL,
    auth TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS social_posts (
    id TEXT PRIMARY KEY,
    signal_id TEXT NOT NULL,
    platform TEXT NOT NULL,
    posted_at TEXT NOT NULL,
    UNIQUE(signal_id, platform)
  );

  CREATE TABLE IF NOT EXISTS settled_outcomes (
    id          TEXT PRIMARY KEY,
    signal_id   TEXT NOT NULL UNIQUE,
    game_id     TEXT,
    league      TEXT NOT NULL DEFAULT '',
    signal_type TEXT NOT NULL DEFAULT '',
    sources     TEXT NOT NULL DEFAULT '[]',
    team        TEXT,
    market      TEXT NOT NULL DEFAULT 'spread',
    home_score  INTEGER,
    away_score  INTEGER,
    line_at_signal REAL,
    closing_line   REAL,
    actual_result  REAL,
    hit         INTEGER,
    clv         REAL,
    recorded_at TEXT NOT NULL,
    created_at  TEXT DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS backfill_progress (
    id               TEXT PRIMARY KEY,
    league           TEXT NOT NULL,
    season           TEXT NOT NULL,
    phase            TEXT NOT NULL,
    status           TEXT NOT NULL DEFAULT 'pending',
    records_inserted INTEGER DEFAULT 0,
    error            TEXT,
    started_at       TEXT,
    completed_at     TEXT,
    created_at       TEXT NOT NULL
  );
`);

// Migration: add tweet columns to distribution_drafts if missing.
(function migrateDistributionDrafts() {
  try {
    const cols = (sqlite.prepare("PRAGMA table_info(distribution_drafts)").all() as any[]).map((c: any) => c.name);
    if (!cols.includes("tweet_id"))  sqlite.exec("ALTER TABLE distribution_drafts ADD COLUMN tweet_id TEXT;");
    if (!cols.includes("tweet_url")) sqlite.exec("ALTER TABLE distribution_drafts ADD COLUMN tweet_url TEXT;");
    if (!cols.includes("posted_at")) sqlite.exec("ALTER TABLE distribution_drafts ADD COLUMN posted_at TEXT;");
  } catch (e: any) {
    console.warn("[db] distribution_drafts migration skipped:", e.message);
  }
})();

// Migration: add source_name to source_scores if missing.
(function migrateSourceScoreName() {
  try {
    const cols = (sqlite.prepare("PRAGMA table_info(source_scores)").all() as any[]).map((c: any) => c.name);
    if (!cols.includes("source_name")) {
      sqlite.exec("ALTER TABLE source_scores ADD COLUMN source_name TEXT;");
      console.log("[db] migrated: source_scores.source_name added");
    }
  } catch (e: any) {
    console.warn("[db] source_scores source_name migration skipped:", e.message);
  }
})();

// Sprint 10 migration: add beta_until to users if it doesn't exist yet.
// SQLite does not support IF NOT EXISTS on ALTER TABLE, so we check PRAGMA.
// This is safe to run on every startup.
(function migrateBetaUntil() {
  try {
    const cols = (sqlite.prepare("PRAGMA table_info(users)").all() as any[]).map((c: any) => c.name);
    if (!cols.includes("beta_until")) {
      sqlite.exec("ALTER TABLE users ADD COLUMN beta_until TEXT;");
      console.log("[db] migrated: users.beta_until added");
    }
  } catch (e: any) {
    console.warn("[db] beta_until migration skipped:", e.message);
  }
})();

function uuid() {
  return crypto.randomUUID();
}
function now() {
  return new Date().toISOString();
}

// ─── IStorage interface ───────────────────────────────────────────────────────
export interface ReplayMarketState {
  game_id: string;
  as_of: string;
  latest_snapshot: OddsSnapshotRow | null;
  snapshot_history: OddsSnapshotRow[];
  signals: ReplaySignalState[];
  clv_states: CLVState[];
}

export interface SignalHistoryRow {
  id: string;
  signal_id: string;
  previous_state: SignalLifecycleState | null;
  new_state: SignalLifecycleState;
  reason: string | null;
  metadata: string | null;
  created_at: string;
}

export interface ReplaySignalState {
  signal: LiveSignal;
  history: SignalHistoryRow[];
}

export interface CLVState {
  signal_id: string;
  game_id: string;
  market: string;
  line_at_signal: number | null;
  closing_line: number | null;
  clv: number | null;
}

export interface ReplayMarketStateInput {
  game_id: string;
  as_of: string;
}
export interface IStorage {
  // Sources
  getSources(): Source[];
  getSource(id: string): Source | undefined;
  createSource(data: InsertSource): Source;
  // Events
  getEvents(): Event[];
  getEvent(id: string): Event | undefined;
  createEvent(data: InsertEvent): Event;
  // Claims
  getClaims(): Claim[];
  getClaimsByEvent(event_id: string): Claim[];
  getClaim(id: string): Claim | undefined;
  createClaim(data: InsertClaim): Claim;
  updateClaimStatus(id: string, status: string): Claim | undefined;
  // Evidence
  getEvidenceForClaim(claim_id: string): Evidence[];
  createEvidence(data: InsertEvidence): Evidence;
  // Verdicts
  getVerdicts(): Verdict[];
  getVerdictForClaim(claim_id: string): Verdict | undefined;
  createVerdict(data: InsertVerdict): Verdict;
  getReviewQueue(): Verdict[];
  resolveReview(verdict_id: string): Verdict | undefined;
  // Source Scores
  getSourceScores(): (SourceScore & { source_name: string; trust_tier: string | null; source_type: string | null; source_url: string | null })[];
  getSourceScore(source_id: string): SourceScore | undefined;
  upsertSourceScore(data: InsertSourceScore): SourceScore;
  // Alerts
  getAlerts(): Alert[];
  createAlert(data: InsertAlert): Alert;
  markAlertSent(id: string): Alert | undefined;
  // Waitlist
  addToWaitlist(data: InsertWaitlist): Waitlist;
  getWaitlist(): Waitlist[];
  waitlistEmailExists(email: string): boolean;
  // Agent Logs
  logAgentAction(data: InsertAgentLog): AgentLog;
  getAgentLogs(limit?: number): AgentLog[];
  // Signal Feed
  getSignalFeed(filters?: { league?: string; topic?: string; verdict?: string }): SignalFeedItem[];
  // Digest Subscribers
  addDigestSubscriber(data: Omit<InsertDigestSubscriber, 'id'>): DigestSubscriber;
  getDigestSubscribers(): DigestSubscriber[];
  unsubscribeDigest(token: string): boolean;
  digestEmailExists(email: string): boolean;
  // Signals (admin)
  deleteSignal(id: string): boolean;
}

// ─── Implementation ────────────────────────────────────────────────────────────
export class SqliteStorage implements IStorage {
  getSources(): Source[] {
    return db.select().from(sources).orderBy(desc(sources.created_at)).all();
  }
  getSource(id: string): Source | undefined {
    return db.select().from(sources).where(eq(sources.id, id)).get();
  }
  createSource(data: InsertSource): Source {
    const row = { ...data, id: uuid(), created_at: now() };
    return db.insert(sources).values(row).returning().get();
  }

  getEvents(): Event[] {
    return db.select().from(events).orderBy(desc(events.created_at)).all();
  }
  getEvent(id: string): Event | undefined {
    return db.select().from(events).where(eq(events.id, id)).get();
  }
  createEvent(data: InsertEvent): Event {
    const row = { ...data, id: uuid(), created_at: now(), updated_at: now() };
    return db.insert(events).values(row).returning().get();
  }

  getClaims(): Claim[] {
    return db.select().from(claims).orderBy(desc(claims.created_at)).all();
  }
  getClaimsByEvent(event_id: string): Claim[] {
    return db.select().from(claims).where(eq(claims.event_id, event_id)).all();
  }
  getClaim(id: string): Claim | undefined {
    return db.select().from(claims).where(eq(claims.id, id)).get();
  }
  createClaim(data: InsertClaim): Claim {
    const row = { ...data, id: uuid(), created_at: now() };
    return db.insert(claims).values(row).returning().get();
  }
  updateClaimStatus(id: string, status: string): Claim | undefined {
    return db.update(claims).set({ claim_status: status }).where(eq(claims.id, id)).returning().get();
  }

  getEvidenceForClaim(claim_id: string): Evidence[] {
    return db.select().from(evidence).where(eq(evidence.claim_id, claim_id)).all();
  }
  createEvidence(data: InsertEvidence): Evidence {
    const row = { ...data, id: uuid(), created_at: now() };
    return db.insert(evidence).values(row).returning().get();
  }

  getVerdicts(): Verdict[] {
    return db.select().from(verdicts).orderBy(desc(verdicts.created_at)).all();
  }
  getVerdictForClaim(claim_id: string): Verdict | undefined {
    return db.select().from(verdicts).where(eq(verdicts.claim_id, claim_id)).get();
  }
  createVerdict(data: InsertVerdict): Verdict {
    const row = { ...data, id: uuid(), created_at: now() };
    return db.insert(verdicts).values(row).returning().get();
  }
  getReviewQueue(): Verdict[] {
    return db.select().from(verdicts)
      .where(eq(verdicts.needs_human_review, 1))
      .orderBy(desc(verdicts.created_at))
      .all();
  }
  resolveReview(verdict_id: string): Verdict | undefined {
    return db.update(verdicts)
      .set({ needs_human_review: 0 })
      .where(eq(verdicts.id, verdict_id))
      .returning().get();
  }

  getSourceScores(): (SourceScore & { source_name: string; trust_tier: string | null; source_type: string | null; source_url: string | null; reliability_score: string | null })[] {
    const rows = sqlite.prepare(`
      SELECT ss.*,
             COALESCE(ss.source_name, s.name) AS source_name,
             s.trust_tier        AS trust_tier,
             s.source_type       AS source_type,
             s.url               AS source_url,
             s.reliability_score AS reliability_score
      FROM source_scores ss
      LEFT JOIN sources s ON ss.source_id = s.id
      ORDER BY ss.overall_accuracy DESC
    `).all() as any[];
    const seen = new Map<string, any>();
    for (const row of rows) {
      const name = row.source_name ?? "Unknown";
      const key  = row.source_id
        ?? name.toLowerCase().replace(/[-_\s]+/g, " ").trim();
      if (!seen.has(key)) seen.set(key, { ...row, source_name: name });
    }
    return Array.from(seen.values());
  }
  getSourceScore(source_id: string): SourceScore | undefined {
    return db.select().from(source_scores).where(eq(source_scores.source_id, source_id)).get();
  }
  upsertSourceScore(data: InsertSourceScore): SourceScore {
    if (data.source_id) {
      sqlite.prepare(
        `INSERT OR IGNORE INTO sources (id, name, source_type, created_at) VALUES (?, ?, 'auto', ?)`
      ).run(data.source_id, data.source_name ?? data.source_id, now());
    }
    const existing = this.getSourceScore(data.source_id ?? "");
    if (existing) {
      return db.update(source_scores)
        .set({ ...data, updated_at: now() })
        .where(eq(source_scores.source_id, data.source_id ?? ""))
        .returning().get()!;
    }
    const row = { ...data, id: uuid(), updated_at: now() };
    return db.insert(source_scores).values(row).returning().get();
  }

  cleanSourceScoreDuplicates(): { duplicateSourceIds: any[]; deletedRows: number; finalCount: number } {
    const dupRows = sqlite.prepare(`
      SELECT source_id, COUNT(*) as cnt
      FROM source_scores
      GROUP BY source_id
      HAVING COUNT(*) > 1
    `).all() as any[];

    const deleteResult = sqlite.prepare(`
      DELETE FROM source_scores WHERE id IN (
        SELECT id FROM (
          SELECT id, ROW_NUMBER() OVER (
            PARTITION BY source_id ORDER BY overall_accuracy DESC, updated_at DESC
          ) as rn
          FROM source_scores
        ) WHERE rn > 1
      )
    `).run();

    const finalResult = sqlite.prepare(`SELECT COUNT(*) as cnt FROM source_scores`).get() as any;

    return {
      duplicateSourceIds: dupRows,
      deletedRows: deleteResult.changes,
      finalCount: finalResult?.cnt ?? 0,
    };
  }

  getAlerts(): Alert[] {
    return db.select().from(alerts).orderBy(desc(alerts.created_at)).all();
  }
  createAlert(data: InsertAlert): Alert {
    const row = { ...data, id: uuid(), created_at: now() };
    return db.insert(alerts).values(row).returning().get();
  }
  markAlertSent(id: string): Alert | undefined {
    return db.update(alerts).set({ sent_at: now() }).where(eq(alerts.id, id)).returning().get();
  }

  addToWaitlist(data: InsertWaitlist): Waitlist {
    const row = { ...data, id: uuid(), created_at: now() };
    return db.insert(waitlist).values(row).returning().get();
  }
  getWaitlist(): Waitlist[] {
    return db.select().from(waitlist).orderBy(desc(waitlist.created_at)).all();
  }
  waitlistEmailExists(email: string): boolean {
    const row = db.select().from(waitlist).where(eq(waitlist.email, email)).get();
    return !!row;
  }

  logAgentAction(data: InsertAgentLog): AgentLog {
    return db.insert(agent_logs).values(data).returning().get();
  }
  getAgentLogs(limit = 100): AgentLog[] {
    return db.select().from(agent_logs)
      .orderBy(desc(agent_logs.timestamp))
      .limit(limit)
      .all();
  }

  getSignalFeed(filters?: { league?: string; topic?: string; verdict?: string }): SignalFeedItem[] {
    // Raw SQL join for the denormalized feed
    let query = `
      SELECT 
        v.id, e.player, e.team, e.league, e.topic,
        c.normalized_claim, v.verdict, v.confidence_score,
        v.needs_human_review, e.urgency_score, e.impact_score,
        s.name as source_name, s.trust_tier,
        v.rationale, e.id as event_id, c.id as claim_id,
        v.created_at
      FROM verdicts v
      LEFT JOIN claims c ON c.id = v.claim_id
      LEFT JOIN events e ON e.id = c.event_id
      LEFT JOIN sources s ON s.id = c.source_id
      WHERE v.needs_human_review = 0
    `;
    const params: string[] = [];
    if (filters?.league) { query += ` AND e.league = ?`; params.push(filters.league); }
    if (filters?.topic) { query += ` AND e.topic = ?`; params.push(filters.topic); }
    if (filters?.verdict) { query += ` AND v.verdict = ?`; params.push(filters.verdict); }
    query += ` ORDER BY v.created_at DESC LIMIT 100`;
    return sqlite.prepare(query).all(...params) as SignalFeedItem[];
  }

  // ─── Signals ───────────────────────────────────────────────────────────────
  getSignals(publicOnly = true): Signal[] {
    if (publicOnly) {
      return db.select().from(signals).where(eq(signals.is_public, true)).orderBy(desc(signals.published_at)).all();
    }
    return db.select().from(signals).orderBy(desc(signals.published_at)).all();
  }
  getSignal(id: string): Signal | undefined {
    return db.select().from(signals).where(eq(signals.id, id)).get();
  }
  getFeaturedSignal(): Signal | undefined {
    return db.select().from(signals).where(and(eq(signals.is_featured, true), eq(signals.is_public, true))).get();
  }
  createSignal(data: InsertSignal): Signal {
    const row = { ...data, id: uuid(), created_at: now(), updated_at: now() };
    return db.insert(signals).values(row).returning().get();
  }
  updateSignal(id: string, data: Partial<InsertSignal>): Signal | undefined {
    return db.update(signals).set({ ...data, updated_at: now() }).where(eq(signals.id, id)).returning().get();
  }
  deleteSignal(id: string): boolean {
    sqlite.prepare(`DELETE FROM source_notes WHERE signal_id = ?`).run(id);
    sqlite.prepare(`DELETE FROM signal_ops_queue WHERE signal_id = ?`).run(id);
    sqlite.prepare(`DELETE FROM distribution_drafts WHERE signal_id = ?`).run(id);
    sqlite.prepare(`DELETE FROM social_posts WHERE signal_id = ?`).run(id);
    const result = db.delete(signals).where(eq(signals.id, id)).returning().get();
    return !!result;
  }
  signalExists(): boolean {
    const row = db.select().from(signals).get();
    return !!row;
  }

  // ─── Source Notes ──────────────────────────────────────────────────────────
  getSourceNotes(signal_id: string): SourceNote[] {
    return db.select().from(source_notes).where(eq(source_notes.signal_id, signal_id)).all();
  }
  createSourceNote(data: InsertSourceNote): SourceNote {
    const row = { ...data, id: uuid(), created_at: now() };
    return db.insert(source_notes).values(row).returning().get();
  }

  // ─── Users ─────────────────────────────────────────────────────────────────
  getUserByEmail(email: string): User | undefined {
    const normalizedEmail = email.trim().toLowerCase();
    if (!normalizedEmail) return undefined;
    return sqlite.prepare(`SELECT * FROM users WHERE lower(email) = ? LIMIT 1`).get(normalizedEmail) as User | undefined;
  }
  getUserByStripeCustomer(customerId: string): User | undefined {
    return db.select().from(users).where(eq(users.stripe_customer_id, customerId)).get();
  }
  getUser(id: string): User | undefined {
    return db.select().from(users).where(eq(users.id, id)).get();
  }
  upsertUser(data: InsertUser): User {
    const normalizedData = data.email ? { ...data, email: data.email.trim().toLowerCase() } : data;
    const existing = normalizedData.email ? this.getUserByEmail(normalizedData.email) : undefined;
    if (existing) {
      return db.update(users).set({ ...normalizedData, updated_at: now() }).where(eq(users.id, existing.id)).returning().get()!;
    }
    const row = { ...normalizedData, id: uuid(), created_at: now(), updated_at: now() };
    return db.insert(users).values(row).returning().get();
  }
  updateUserByStripeCustomer(customerId: string, data: Partial<InsertUser>): User | undefined {
    return db.update(users).set({ ...data, updated_at: now() }).where(eq(users.stripe_customer_id, customerId)).returning().get();
  }
  getAllUsers(): User[] {
    return db.select().from(users).orderBy(desc(users.created_at)).all();
  }

  // ─── Digest Subscribers ─────────────────────────────────────────────────────
  addDigestSubscriber(data: Omit<InsertDigestSubscriber, 'id'>): DigestSubscriber {
    // Upsert: if email already exists, reactivate
    const existing = db.select().from(digest_subscribers).where(eq(digest_subscribers.email, data.email)).get();
    if (existing) {
      return db.update(digest_subscribers)
        .set({ is_active: true, source: data.source })
        .where(eq(digest_subscribers.id, existing.id))
        .returning().get()!;
    }
    const row = { ...data, id: uuid(), created_at: now() };
    return db.insert(digest_subscribers).values(row).returning().get();
  }
  getDigestSubscribers(): DigestSubscriber[] {
    return db.select().from(digest_subscribers)
      .where(eq(digest_subscribers.is_active, true))
      .orderBy(desc(digest_subscribers.created_at))
      .all();
  }
  unsubscribeDigest(token: string): boolean {
    const row = db.select().from(digest_subscribers).where(eq(digest_subscribers.unsubscribe_token, token)).get();
    if (!row) return false;
    db.update(digest_subscribers).set({ is_active: false }).where(eq(digest_subscribers.id, row.id)).run();
    return true;
  }
  digestEmailExists(email: string): boolean {
    const row = db.select().from(digest_subscribers).where(eq(digest_subscribers.email, email)).get();
    return !!row && row.is_active;
  }

  // ─── Signal Ops Queue ──────────────────────────────────────────────────────
  createSignalOpsItem(data: Record<string, any>): Record<string, any> {
    const row: Record<string, any> = { ...data, id: uuid(), created_at: now() };
    return sqlite.prepare(`INSERT INTO signal_ops_queue (id,source_name,source_url,raw_headline,raw_body,player_tags,team_tags,ingest_timestamp,cluster_id,normalized_headline,normalized_summary,player,team,signal_type,confidence_score,decision,reason,source_count,conflict_flags,signal_id,processed_at,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING *`).get(row.id,row.source_name,row.source_url??null,row.raw_headline,row.raw_body??null,row.player_tags??'[]',row.team_tags??'[]',row.ingest_timestamp,row.cluster_id??null,row.normalized_headline??null,row.normalized_summary??null,row.player??null,row.team??null,row.signal_type??null,row.confidence_score??0,row.decision,row.reason??null,row.source_count??1,row.conflict_flags??'[]',row.signal_id??null,row.processed_at??null,row.created_at) as Record<string,any>;
  }
  updateSignalOpsItem(id: string, data: Record<string, any>): void {
    const sets = Object.entries(data).map(([k]) => `${k}=?`).join(',');
    const vals = Object.values(data);
    sqlite.prepare(`UPDATE signal_ops_queue SET ${sets} WHERE id=?`).run(...vals, id);
  }
  getSignalOpsQueue(decision?: string): Record<string, any>[] {
    if (decision) return sqlite.prepare(`SELECT * FROM signal_ops_queue WHERE decision=? ORDER BY created_at DESC LIMIT 200`).all(decision) as Record<string,any>[];
    return sqlite.prepare(`SELECT * FROM signal_ops_queue ORDER BY created_at DESC LIMIT 200`).all() as Record<string,any>[];
  }
  getSignalOpsItem(id: string): Record<string, any> | undefined {
    return sqlite.prepare(`SELECT * FROM signal_ops_queue WHERE id=?`).get(id) as Record<string,any>|undefined;
  }
  signalOpsHeadlineExists(headline: string, withinHours = 24): boolean {
    const cutoff = new Date(Date.now() - withinHours * 3600 * 1000).toISOString();
    const row = sqlite.prepare(`SELECT id FROM signal_ops_queue WHERE raw_headline=? AND created_at > ? AND decision != 'reject' LIMIT 1`).get(headline, cutoff);
    return !!row;
  }
  resolveSignalOpsItem(id: string, signalId?: string): void {
    sqlite.prepare(`UPDATE signal_ops_queue SET decision='published', signal_id=?, processed_at=? WHERE id=?`).run(signalId??null, now(), id);
  }
  rejectSignalOpsItem(id: string, reason: string): void {
    sqlite.prepare(`UPDATE signal_ops_queue SET decision='reject', reason=?, processed_at=? WHERE id=?`).run(reason, now(), id);
  }

  // ─── Site Watch Log ───────────────────────────────────────────────────────
  createSiteWatchRun(data: { status: string; checks: any[]; anomalies: any[]; recommended_action?: string }): Record<string,any> {
    const id = uuid();
    const ts2 = now();
    sqlite.prepare(`INSERT INTO site_watch_log (id,run_timestamp,status,checks,anomalies,recommended_action,alert_sent,created_at) VALUES (?,?,?,?,?,?,0,?)`).run(id,ts2,data.status,JSON.stringify(data.checks),JSON.stringify(data.anomalies),data.recommended_action??null,ts2);
    return { id, run_timestamp: ts2, ...data };
  }
  getSiteWatchLog(limit = 50): Record<string,any>[] {
    return (sqlite.prepare(`SELECT * FROM site_watch_log ORDER BY run_timestamp DESC LIMIT ?`).all(limit) as Record<string,any>[]).map(r => ({
      ...r, checks: JSON.parse(r.checks??'[]'), anomalies: JSON.parse(r.anomalies??'[]')
    }));
  }
  markSiteWatchAlertSent(id: string): void {
    sqlite.prepare(`UPDATE site_watch_log SET alert_sent=1 WHERE id=?`).run(id);
  }

  // ─── Event Log ─────────────────────────────────────────────────────────────
  logEvent(data: InsertEventLog): EventLog {
    const row = { ...data, id: uuid(), created_at: now() };
    return db.insert(event_log).values(row).returning().get();
  }
  getEventLog(limit = 200): EventLog[] {
    return db.select().from(event_log).orderBy(desc(event_log.created_at)).limit(limit).all();
  }

  // ─── Distribution Drafts ──────────────────────────────────────────────────
  createDistributionDraft(data: {
    signal_id: string; channel: string; status: string;
    copy: string; headline: string; notes: string;
  }): Record<string, any> {
    const id = uuid();
    const ts = now();
    sqlite.prepare(
      `INSERT INTO distribution_drafts (id,signal_id,channel,status,copy,headline,notes,created_at,updated_at)
       VALUES (?,?,?,?,?,?,?,?,?)`
    ).run(id, data.signal_id, data.channel, data.status, data.copy, data.headline, data.notes ?? '', ts, ts);
    return sqlite.prepare(`SELECT * FROM distribution_drafts WHERE id=?`).get(id) as Record<string,any>;
  }

  getDistributionDrafts(filters?: { status?: string; channel?: string; signal_id?: string }): Record<string, any>[] {
    let q = `SELECT d.*, s.title as signal_title, s.player_name, s.team, s.confidence_score, s.verdict
             FROM distribution_drafts d
             LEFT JOIN signals s ON s.id = d.signal_id`;
    const params: any[] = [];
    const clauses: string[] = [];
    if (filters?.status)    { clauses.push(`d.status=?`);    params.push(filters.status); }
    if (filters?.channel)   { clauses.push(`d.channel=?`);   params.push(filters.channel); }
    if (filters?.signal_id) { clauses.push(`d.signal_id=?`); params.push(filters.signal_id); }
    if (clauses.length > 0) q += ` WHERE ` + clauses.join(` AND `);
    q += ` ORDER BY d.created_at DESC LIMIT 200`;
    return sqlite.prepare(q).all(...params) as Record<string,any>[];
  }

  getDistributionDraft(id: string): Record<string, any> | undefined {
    return sqlite.prepare(
      `SELECT d.*, s.title as signal_title, s.player_name, s.team, s.confidence_score, s.verdict
       FROM distribution_drafts d
       LEFT JOIN signals s ON s.id = d.signal_id
       WHERE d.id=?`
    ).get(id) as Record<string,any>|undefined;
  }

  distributionDraftExists(signal_id: string, channel: string): boolean {
    const row = sqlite.prepare(
      `SELECT id FROM distribution_drafts WHERE signal_id=? AND channel=? AND status NOT IN ('rejected') LIMIT 1`
    ).get(signal_id, channel);
    return !!row;
  }

  updateDistributionDraft(id: string, data: { status?: string; copy?: string; notes?: string; tweet_id?: string; tweet_url?: string; posted_at?: string }): Record<string, any> | undefined {
    const ts = now();
    const sets: string[] = [];
    const vals: any[] = [];
    if (data.status    !== undefined) { sets.push(`status=?`);    vals.push(data.status); }
    if (data.copy      !== undefined) { sets.push(`copy=?`);      vals.push(data.copy); }
    if (data.notes     !== undefined) { sets.push(`notes=?`);     vals.push(data.notes); }
    if (data.tweet_id  !== undefined) { sets.push(`tweet_id=?`);  vals.push(data.tweet_id); }
    if (data.tweet_url !== undefined) { sets.push(`tweet_url=?`); vals.push(data.tweet_url); }
    if (data.posted_at !== undefined) { sets.push(`posted_at=?`); vals.push(data.posted_at); }
    if (sets.length === 0) return this.getDistributionDraft(id);
    sets.push(`updated_at=?`); vals.push(ts);
    sqlite.prepare(`UPDATE distribution_drafts SET ${sets.join(',')} WHERE id=?`).run(...vals, id);
    return this.getDistributionDraft(id);
  }

  // ─── Social Posts ─────────────────────────────────────────────────────────

  hasSocialPost(signal_id: string, platform: string): boolean {
    const row = sqlite.prepare(
      "SELECT 1 FROM social_posts WHERE signal_id=? AND platform=?"
    ).get(signal_id, platform);
    return !!row;
  }

  recordSocialPost(signal_id: string, platform: string): void {
    sqlite.prepare(
      "INSERT OR IGNORE INTO social_posts (id, signal_id, platform, posted_at) VALUES (?, ?, ?, ?)"
    ).run(crypto.randomUUID(), signal_id, platform, new Date().toISOString());
  }

  // ─── Daily Ops Summary ────────────────────────────────────────────────────
  createDailyOpsSummary(data: Record<string, any>): Record<string, any> {
    const ts = now();
    sqlite.prepare(
      `INSERT OR REPLACE INTO daily_ops_summary
       (id,date,generated_at,site_health,signal_pipeline,content_queue,funnel,top_actions,email_sent,created_at)
       VALUES (?,?,?,?,?,?,?,?,?,?)`
    ).run(
      data.id, data.date, data.generated_at,
      JSON.stringify(data.site_health),
      JSON.stringify(data.signal_pipeline),
      JSON.stringify(data.content_queue),
      JSON.stringify(data.funnel),
      JSON.stringify(data.top_actions),
      data.email_sent ? 1 : 0,
      ts,
    );
    return this.getDailyOpsSummary(data.id) as Record<string,any>;
  }

  getDailyOpsSummaries(limit = 30): Record<string, any>[] {
    return (sqlite.prepare(`SELECT * FROM daily_ops_summary ORDER BY date DESC LIMIT ?`).all(limit) as Record<string,any>[]).map(r => ({
      ...r,
      site_health:     JSON.parse(r.site_health     ?? '{}'),
      signal_pipeline: JSON.parse(r.signal_pipeline ?? '{}'),
      content_queue:   JSON.parse(r.content_queue   ?? '{}'),
      funnel:          JSON.parse(r.funnel           ?? '{}'),
      top_actions:     JSON.parse(r.top_actions      ?? '[]'),
    }));
  }

  getDailyOpsSummary(id: string): Record<string, any> | undefined {
    const r = sqlite.prepare(`SELECT * FROM daily_ops_summary WHERE id=?`).get(id) as Record<string,any>|undefined;
    if (!r) return undefined;
    return {
      ...r,
      site_health:     JSON.parse(r.site_health     ?? '{}'),
      signal_pipeline: JSON.parse(r.signal_pipeline ?? '{}'),
      content_queue:   JSON.parse(r.content_queue   ?? '{}'),
      funnel:          JSON.parse(r.funnel           ?? '{}'),
      top_actions:     JSON.parse(r.top_actions      ?? '[]'),
    };
  }

  getLatestDailyOpsSummary(): Record<string, any> | undefined {
    const r = sqlite.prepare(`SELECT * FROM daily_ops_summary ORDER BY date DESC LIMIT 1`).get() as Record<string,any>|undefined;
    if (!r) return undefined;
    return {
      ...r,
      site_health:     JSON.parse(r.site_health     ?? '{}'),
      signal_pipeline: JSON.parse(r.signal_pipeline ?? '{}'),
      content_queue:   JSON.parse(r.content_queue   ?? '{}'),
      funnel:          JSON.parse(r.funnel           ?? '{}'),
      top_actions:     JSON.parse(r.top_actions      ?? '[]'),
    };
  }

  markDailyOpsSummaryEmailSent(id: string): void {
    sqlite.prepare(`UPDATE daily_ops_summary SET email_sent=1 WHERE id=?`).run(id);
  }
}

export const storage = new SqliteStorage();

/* ─── Pipeline Health (module-level) ─────────────────────────────────────── */

export function recordPipelineHealth(
  component: string,
  status: "ok" | "warning" | "error",
  result: Record<string, any>,
): void {
  const ts = new Date().toISOString();
  sqlite.prepare(`
    INSERT INTO pipeline_health (component, last_run_at, last_status, last_result)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(component) DO UPDATE SET
      last_run_at = excluded.last_run_at,
      last_status = excluded.last_status,
      last_result = excluded.last_result
  `).run(component, ts, status, JSON.stringify(result));
}

export function getAllPipelineHealth(): Array<{
  component:   string;
  last_run_at: string | null;
  last_status: string | null;
  last_result: Record<string, any>;
}> {
  const rows = sqlite.prepare(`SELECT * FROM pipeline_health`).all() as any[];
  return rows.map(r => ({
    component:   r.component,
    last_run_at: r.last_run_at  ?? null,
    last_status: r.last_status  ?? null,
    last_result: r.last_result ? JSON.parse(r.last_result) : {},
  }));
}

/* ─── Alert Preferences (module-level, used by alerts.ts) ────────────────── */

export interface AlertPreferences {
  email: string;
  leagues: string[];
  signal_types: string[];
  min_confidence: number;
  channels: string[];
  is_active: boolean;
}

export function getAlertPreferences(email: string): AlertPreferences | null {
  const row = sqlite.prepare(`SELECT * FROM alert_preferences WHERE email = ?`).get(email) as any;
  if (!row) return null;
  return {
    email: row.email,
    leagues:        JSON.parse(row.leagues       ?? '["NBA","MLB"]'),
    signal_types:   JSON.parse(row.signal_types  ?? '[]'),
    min_confidence: row.min_confidence           ?? 80,
    channels:       JSON.parse(row.channels      ?? '["email"]'),
    is_active:      row.is_active === 1,
  };
}

export function upsertAlertPreferences(data: AlertPreferences): void {
  const ts = new Date().toISOString();
  sqlite.prepare(`
    INSERT INTO alert_preferences (id, email, leagues, signal_types, min_confidence, channels, is_active, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(email) DO UPDATE SET
      leagues        = excluded.leagues,
      signal_types   = excluded.signal_types,
      min_confidence = excluded.min_confidence,
      channels       = excluded.channels,
      is_active      = excluded.is_active,
      updated_at     = excluded.updated_at
  `).run(
    crypto.randomUUID(), data.email,
    JSON.stringify(data.leagues),
    JSON.stringify(data.signal_types),
    data.min_confidence,
    JSON.stringify(data.channels),
    data.is_active ? 1 : 0,
    ts, ts,
  );
}

export function getActiveAlertUsers(): AlertPreferences[] {
  const rows = sqlite.prepare(`
    SELECT ap.* FROM alert_preferences ap
    JOIN users u ON u.email = ap.email
    WHERE ap.is_active = 1
      AND (
        (u.plan = 'pro' AND u.access_status = 'active')
        OR (u.beta_until IS NOT NULL AND u.beta_until > datetime('now'))
      )
  `).all() as any[];
  return rows.map(row => ({
    email:          row.email,
    leagues:        JSON.parse(row.leagues       ?? '["NBA","MLB"]'),
    signal_types:   JSON.parse(row.signal_types  ?? '[]'),
    min_confidence: row.min_confidence           ?? 80,
    channels:       JSON.parse(row.channels      ?? '["email"]'),
    is_active:      row.is_active === 1,
  }));
}

/* ─── Push Subscriptions (module-level, used by alerts.ts) ───────────────── */

export interface PushSubscriptionRow {
  email:    string;
  endpoint: string;
  p256dh:   string;
  auth:     string;
}

export function getPushSubscriptions(email?: string): PushSubscriptionRow[] {
  const rows = email
    ? sqlite.prepare(`SELECT * FROM push_subscriptions WHERE email = ?`).all(email) as any[]
    : sqlite.prepare(`SELECT * FROM push_subscriptions`).all() as any[];
  return rows.map(r => ({ email: r.email, endpoint: r.endpoint, p256dh: r.p256dh, auth: r.auth }));
}

export function upsertPushSubscription(data: PushSubscriptionRow): void {
  const ts = new Date().toISOString();
  sqlite.prepare(`
    INSERT INTO push_subscriptions (id, email, endpoint, p256dh, auth, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
    ON CONFLICT(endpoint) DO UPDATE SET
      email  = excluded.email,
      p256dh = excluded.p256dh,
      auth   = excluded.auth
  `).run(crypto.randomUUID(), data.email, data.endpoint, data.p256dh, data.auth, ts);
}

export function deletePushSubscription(endpoint: string): void {
  sqlite.prepare(`DELETE FROM push_subscriptions WHERE endpoint = ?`).run(endpoint);
}

/* ─── Settled Outcomes (persistent accuracy source) ──────────────────────── */

export function insertSettledOutcome(data: {
  signal_id:      string;
  game_id:        string | null;
  league:         string;
  signal_type:    string;
  sources:        string; // JSON array
  team:           string | null;
  market:         string;
  home_score:     number | null;
  away_score:     number | null;
  line_at_signal: number | null;
  closing_line:   number | null;
  actual_result:  number | null;
  hit:            boolean | null;
  clv:            number | null;
  recorded_at:    string;
}): void {
  sqlite.prepare(`
    INSERT OR IGNORE INTO settled_outcomes
      (id, signal_id, game_id, league, signal_type, sources, team, market,
       home_score, away_score, line_at_signal, closing_line, actual_result,
       hit, clv, recorded_at, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    crypto.randomUUID(),
    data.signal_id, data.game_id,
    data.league, data.signal_type, data.sources, data.team, data.market,
    data.home_score, data.away_score, data.line_at_signal, data.closing_line,
    data.actual_result,
    data.hit === null ? null : (data.hit ? 1 : 0),
    data.clv, data.recorded_at, new Date().toISOString(),
  );
}

export function getSettledOutcomesForAccuracy(): Array<{
  signal_id:   string;
  league:      string;
  signal_type: string;
  sources:     string;
  hit:         number | null;
  clv:         number | null;
}> {
  return sqlite.prepare(`
    SELECT signal_id, league, signal_type, sources, hit, clv
    FROM settled_outcomes
    WHERE hit IS NOT NULL
  `).all() as any[];
}

export function getVerifiedCountBySource(): Map<string, number> {
  const rows = sqlite.prepare(`
    SELECT json_extract(src.value, '$.name') AS src_name, COUNT(*) AS cnt
    FROM settled_outcomes, json_each(sources) AS src
    WHERE hit IS NOT NULL
    GROUP BY json_extract(src.value, '$.name')
  `).all() as any[];
  return new Map(rows.map(r => [r.src_name as string, r.cnt as number]));
}

/* ─── Backfill Progress (persistent — survives restarts) ──────────────────── */

export interface BackfillPhase {
  id:               string;
  league:           string;
  season:           string;
  phase:            string;
  status:           "pending" | "running" | "done" | "error";
  records_inserted: number | null;
  error:            string | null;
  started_at:       string | null;
  completed_at:     string | null;
  created_at:       string;
}

export function markBackfillPhase(
  league: string,
  season: string,
  phase: string,
  status: "running" | "done" | "error",
  meta?: { records?: number; error?: string },
): void {
  const id = `${league}|${season}|${phase}`;
  const ts = new Date().toISOString();
  sqlite.prepare(`
    INSERT INTO backfill_progress (id,league,season,phase,status,records_inserted,error,started_at,completed_at,created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?)
    ON CONFLICT(id) DO UPDATE SET
      status=excluded.status,
      records_inserted=CASE WHEN excluded.records_inserted > 0 THEN excluded.records_inserted ELSE records_inserted END,
      error=excluded.error,
      started_at=CASE WHEN excluded.started_at IS NOT NULL THEN excluded.started_at ELSE started_at END,
      completed_at=excluded.completed_at
  `).run(
    id, league, season, phase, status,
    meta?.records ?? 0,
    meta?.error ?? null,
    status === "running" ? ts : null,
    status === "done" || status === "error" ? ts : null,
    ts,
  );
}

export function getBackfillPhase(league: string, season: string, phase: string): BackfillPhase | null {
  const id = `${league}|${season}|${phase}`;
  return (sqlite.prepare("SELECT * FROM backfill_progress WHERE id=?").get(id) as BackfillPhase) ?? null;
}

export function getAllBackfillProgress(): BackfillPhase[] {
  return sqlite.prepare("SELECT * FROM backfill_progress ORDER BY created_at DESC").all() as BackfillPhase[];
}

export function resetBackfillPhases(league: string): void {
  sqlite.prepare("DELETE FROM backfill_progress WHERE league=?").run(league);
}

