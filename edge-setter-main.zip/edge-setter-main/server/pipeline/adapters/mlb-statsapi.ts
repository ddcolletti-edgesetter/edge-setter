/**
 * Edge Setter — MLB Stats API Adapter  (Sprint 7)
 *
 * Source: https://statsapi.mlb.com  (free, no key required)
 * Official MLB data: schedules, lineups, injuries, transactions
 *
 * Fetches:
 *   - Today's schedule (for game_id population)
 *   - Starting pitcher confirmations → lineup_confirm RawEvents
 *   - IL transactions → transaction RawEvents
 */

import { insertRawEvent, upsertGame, getGame, findGameByTeams, getRawEvents, getPipelineDb } from "../store";

const BASE_URL = "https://statsapi.mlb.com/api/v1";

/* ─── Types ─────────────────────────────────────────────── */

interface MLBGame {
  gamePk: number;
  gameDate: string;         // ISO datetime
  status: { abstractGameState: string };
  teams: {
    home: { team: { id: number; name: string; abbreviation: string } };
    away: { team: { id: number; name: string; abbreviation: string } };
  };
  linescore?: unknown;
}

interface MLBScheduleResponse {
  dates: Array<{ date: string; games: MLBGame[] }>;
}

interface MLBTransaction {
  id: number;
  person: { fullName: string };
  fromTeam?: { abbreviation: string };
  toTeam?: { abbreviation: string };
  team: { abbreviation: string };
  date: string;
  typeCode: string;   // "IL" | "DFA" | "ASG" | "SGN" | etc.
  typeDesc: string;
  description: string;
  effectiveDate: string;
}

interface MLBRosterPlayer {
  person: { id: number; fullName: string };
  status: { description: string };
  parentTeamId?: number;
}

/* ─── Fetch today's schedule ─────────────────────────────── */

export async function fetchMLBSchedule(): Promise<MLBGame[]> {
  try {
    const today = new Date().toISOString().slice(0, 10);
    const url = `${BASE_URL}/schedule?sportId=1&date=${today}&hydrate=linescore,team`;
    const resp = await fetch(url);
    if (!resp.ok) { console.error(`[mlb-statsapi] HTTP ${resp.status} schedule`); return []; }
    const data = await resp.json() as MLBScheduleResponse;
    return data.dates.flatMap(d => d.games ?? []);
  } catch (err: any) {
    console.error("[mlb-statsapi] Schedule fetch error:", err.message);
    return [];
  }
}
export async function fetchMLBFinalScores(): Promise<Array<{
  game_id: string;
  home_score: number;
  away_score: number;
}>> {
  try {
    const today = new Date().toISOString().slice(0, 10);
    const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
    const url = `${BASE_URL}/schedule?sportId=1&startDate=${yesterday}&endDate=${today}&hydrate=linescore,team`;
    const resp = await fetch(url);
    if (!resp.ok) { console.error(`[mlb-statsapi] HTTP ${resp.status} final scores`); return []; }
    const data = await resp.json() as MLBScheduleResponse;
    const results: Array<{ game_id: string; home_score: number; away_score: number }> = [];

    for (const date of data.dates) {
      for (const g of date.games) {
        const raw = g as any;
        if (raw.status?.abstractGameState !== "Final") continue;
        const homeRuns = raw.linescore?.teams?.home?.runs;
        const awayRuns = raw.linescore?.teams?.away?.runs;
        if (homeRuns == null || awayRuns == null) continue;

        const canonicalId = `mlb_${raw.gamePk}`;
        const gameDate = g.gameDate.slice(0, 10);

        const game = getGame(canonicalId)
          ?? findGameByTeams("MLB", g.teams.home.team.abbreviation, g.teams.away.team.abbreviation, gameDate);
        if (!game) continue;

        results.push({
          game_id: game.id,
          home_score: Number(homeRuns),
          away_score: Number(awayRuns),
        });
      }
    }
    return results;
  } catch (err: any) {
    console.error("[mlb-statsapi] Final scores error:", err.message);
    return [];
  }
}

/* ─── Ingest MLB games → Game table ─────────────────────── */

export async function ingestMLBSchedule(): Promise<{ games: number }> {
  const games = await fetchMLBSchedule();
  let count = 0;
  for (const g of games) {
    const gameId = `mlb_${g.gamePk}`;
    upsertGame({
      id: gameId,
      league: "MLB",
      home_team: g.teams.home.team.abbreviation,
      away_team: g.teams.away.team.abbreviation,
      game_time: g.gameDate,
      status: mapGameState(g.status.abstractGameState),
      spread_line: null,       // MLB StatsAPI doesn't provide odds — The Odds API does
      spread_team: null,
      total_line: null,
      moneyline_home: null,
      moneyline_away: null,
      open_spread: null,
      open_total: null,
      home_score: null,
      away_score: null,
      source_game_id: String(g.gamePk),
    });
    count++;
  }
  console.log(`[mlb-statsapi] Upserted ${count} games`);
  return { games: count };
}

function mapGameState(state: string): "scheduled" | "live" | "final" | "postponed" {
  const s = state.toLowerCase();
  if (s === "live")      return "live";
  if (s === "final")     return "final";
  if (s.includes("postponed")) return "postponed";
  return "scheduled";
}

/* ─── Fetch IL / transactions ────────────────────────────── */

export async function fetchMLBTransactions(days = 1): Promise<MLBTransaction[]> {
  try {
    const today = new Date().toISOString().slice(0, 10);
    const from  = new Date(Date.now() - days * 86400000).toISOString().slice(0, 10);
    const url = `${BASE_URL}/transactions?sportId=1&startDate=${from}&endDate=${today}`;
    const resp = await fetch(url);
    if (!resp.ok) { console.error(`[mlb-statsapi] HTTP ${resp.status} transactions`); return []; }
    const data = await resp.json() as { transactions: MLBTransaction[] };
    return data.transactions ?? [];
  } catch (err: any) {
    console.error("[mlb-statsapi] Transactions fetch error:", err.message);
    return [];
  }
}

/* ─── Ingest MLB transactions → RawEvents ────────────────── */

export async function ingestMLBTransactions(): Promise<{ created: number }> {
  const txns = await fetchMLBTransactions(1);
  let created = 0;

  // Build dedup set from unprocessed raw events so we skip duplicates within a batch
  // but re-insert (and refresh updated_at on the signal) in subsequent cycles.
  const recentEvents = getRawEvents({ league: "MLB", processed: false, limit: 500 });
  const seenTxIds = new Set<number>(
    recentEvents
      .map(e => (e.payload as any)?.mlb_transaction_id)
      .filter((id): id is number => id != null)
  );

  // SC = Status Change (IL placements + activations), CU = Recalled (IL activation),
  // DES = Designated for Assignment. MLB does not use "IL", "ACT", or "DFA" as typeCodes.
  const relevant = txns.filter(t =>
    (t.typeCode === "SC" && t.description.toLowerCase().includes("injured list")) ||
    t.typeCode === "CU" ||
    t.typeCode === "DES"
  );

  for (const tx of relevant) {
    if (seenTxIds.has(tx.id)) continue;

    const isActivation =
      tx.typeCode === "CU" ||
      (tx.typeCode === "SC" && tx.description.toLowerCase().includes("activated"));
    const team = (tx.toTeam ?? tx.fromTeam ?? tx.team)?.abbreviation ?? "UNK";
    const desc = tx.description.toLowerCase();
    const designation = isActivation ? undefined
      : desc.includes("60-day") ? "IL-60"
      : desc.includes("15-day") ? "IL-15"
      : "IL-10";

    insertRawEvent({
      source_id: "mlb_statsapi",
      source_type: "api",
      league: "MLB",
      game_id: null,
      team,
      player: tx.person.fullName,
      event_type: isActivation ? "transaction" : "injury_update",
      payload: {
        transaction_type: isActivation ? "IL activation" : `${designation} placement`,
        designation,
        notes: tx.description,
        confidence: 92,
        confirmation: "Consensus",
        source_types: ["official report", "transaction"],
        source_labels: ["MLB StatsAPI (official)"],
        source_count: 1,
        sources: [{ name: "MLB StatsAPI", type: "official report" }],
        mlb_transaction_id: tx.id,
        effective_date: tx.effectiveDate,
      },
    });
    seenTxIds.add(tx.id);
    created++;
  }

  console.log(`[mlb-statsapi] MLB transactions: ${created} RawEvents created`);
  return { created };
}

/* ─── Fetch probable pitchers for today ─────────────────── */

export async function fetchProbablePitchers(): Promise<Array<{
  game_id: string;
  home_pitcher: string | null;
  away_pitcher: string | null;
}>> {
  try {
    const today = new Date().toISOString().slice(0, 10);
    const url = `${BASE_URL}/schedule?sportId=1&date=${today}&hydrate=probablePitcher`;
    const resp = await fetch(url);
    if (!resp.ok) { console.error(`[mlb-statsapi] HTTP ${resp.status} probable pitchers`); return []; }
    const data = await resp.json() as MLBScheduleResponse;
    const result: Array<{ game_id: string; home_pitcher: string | null; away_pitcher: string | null }> = [];
    for (const date of data.dates) {
      for (const game of date.games) {
        const g = game as any;
        result.push({
          game_id: `mlb_${g.gamePk}`,
          home_pitcher: g.teams?.home?.probablePitcher?.fullName ?? null,
          away_pitcher: g.teams?.away?.probablePitcher?.fullName ?? null,
        });
      }
    }
    return result;
  } catch (err: any) {
    console.error("[mlb-statsapi] Probable pitchers error:", err.message);
    return [];
  }
}

/* ─── Ingest probable pitcher confirmations ──────────────── */

export async function ingestProbablePitchers(): Promise<{ created: number }> {
  const pitchers = await fetchProbablePitchers();
  let created = 0;

  // Dedup against unprocessed raw events only — after processing, re-insert each cycle
  // so the derived live_signal's updated_at stays current and time-decay doesn't bury it.
  const recentPitcherEvents = getRawEvents({ league: "MLB", processed: false, limit: 500 });
  const seenPitcherKeys = new Set<string>(
    recentPitcherEvents
      .filter(e => e.event_type === "lineup_confirm")
      .map(e => `${e.game_id}|${e.team}|${e.player}`)
  );

  for (const p of pitchers) {
    const game = getGame(p.game_id);
    if (!game) continue;

    for (const [side, pitcher] of [[game.home_team, p.home_pitcher], [game.away_team, p.away_pitcher]] as [string, string | null][]) {
      if (!pitcher) continue;
      const pitcherKey = `${p.game_id}|${side}|${pitcher}`;
      if (seenPitcherKeys.has(pitcherKey)) continue;
      insertRawEvent({
        source_id: "mlb_statsapi",
        source_type: "api",
        league: "MLB",
        game_id: p.game_id,
        team: side,
        player: pitcher,
        event_type: "lineup_confirm",
        payload: {
          status: "confirmed starter",
          notes: `${pitcher} confirmed as starting pitcher for ${side}.`,
          confidence: 90,
          confirmation: "Consensus",
          source_types: ["official report"],
          source_labels: ["MLB StatsAPI (official)"],
          source_count: 1,
          sources: [{ name: "MLB StatsAPI", type: "official report" }],
          pitcher_matchup: true,
          game_time: game.game_time,
          matchup: `${game.away_team} @ ${game.home_team}`,
        },
      });
      seenPitcherKeys.add(pitcherKey);
      created++;
    }
  }

  console.log(`[mlb-statsapi] Probable pitchers: ${created} RawEvents created`);
  return { created };
}

